const express = require('express');
const router = express.Router();

const Student = require('../models/studentModel');

// Create a new student
router.post('/students', async (req, res) => {
  try {
    const student = new Student({
      name: req.body.name,
      semester: req.body.semester,
      age: req.body.age,
      address: req.body.address,
      DateOfBirth: req.body.DateOfBirth
    });

    const savedStudent = await student.save();
    res.status(201).json(savedStudent);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Retrieve all students
router.get('/students', async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update a student by ID
router.put('/students/:id', async (req, res) => {
  try {
    const updatedStudent = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedStudent) {
      return res.status(404).json({ message: "Student not found" });
    }
    res.json(updatedStudent);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete a student by ID
router.delete('/students/:id', async (req, res) => {
  try {
    const removedStudent = await Student.findByIdAndRemove(req.params.id);
    if (!removedStudent) {
      return res.status(404).json({ message: "Student not found" });
    }
    res.json({ message: "Student deleted", student: removedStudent });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
